package app.service;

import app.model.ModelResponse;
import app.model.NseResponse;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;

import java.util.Arrays;
import java.util.List;

@Service
public class RSIintegration {

    private final NSEService nseService;

    public RSIintegration(NSEService nseService) {
        this.nseService = nseService;
    }

    public void integrate(){

        List<ModelResponse> nseResponse =  nseService.getLiveStockDataRestTemplate();
        Flux<ModelResponse> modelResponseFlux = nseService.getLiveStockData();


        modelResponseFlux.subscribe(
                stockData -> {
                    System.out.println("Received stock data: " + stockData);
                   callRSI(stockData.getSymbol());
                },
                error -> System.err.println("Error occurred: " + error),
                () -> System.out.println("Processing completed.")
        );

        System.out.println(nseResponse.size());


    }

    private Double callRSI(String symbol){
        // List<Double> priceData = Arrays.asList(51.0, 51.0, 51.0, 51.0, 51.0, 51.0, 51.0, 51.0, 51.0, 51.0, 51.0,51.0, 51.0, 51.0,51.0);
        List<Double> priceData = Arrays.asList(20.0,20.0);
        int rsiPeriod = 1;

        double rsi = RSICalculator.calculateRSI(priceData, rsiPeriod);
        System.out.println("RSI for : " + symbol + " is " + rsi);

        return rsi;
    }
}
