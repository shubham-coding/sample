package app.service;

import java.util.*;

public class RSICalculator {
    private static final int DEFAULT_PERIOD = 14;

    public static double calculateRSI(List<Double> prices) {
        return calculateRSI(prices, DEFAULT_PERIOD);
    }

    public static double calculateRSI(List<Double> prices, int period) {
        if (prices == null || prices.size() < period + 1) {
            throw new IllegalArgumentException("Insufficient data for RSI calculation");
        }

        double[] up = new double[prices.size()];
        double[] down = new double[prices.size()];

        // Calculate average gain and average loss
        for (int i = 1; i <= period; i++) {
            double priceDiff = prices.get(i) - prices.get(i - 1);
            if (priceDiff > 0) {
                up[i] = priceDiff;
                down[i] = 0;
            } else {
                up[i] = 0;
                down[i] = -priceDiff;
            }
        }

        double avgGain = calculateAverage(up, period);
        double avgLoss = calculateAverage(down, period);

        // Calculate initial RS and RSI
        double rs = avgLoss == 0 ? Double.POSITIVE_INFINITY : avgGain / avgLoss;
        double rsi = 100 - (100 / (1 + rs));

        // Calculate RSI for the remaining data
        for (int i = period + 1; i < prices.size(); i++) {
            double priceDiff = prices.get(i) - prices.get(i - 1);

            if (priceDiff > 0) {
                avgGain = (avgGain * (period - 1) + priceDiff) / period;
                avgLoss = avgLoss * (period - 1) / period;
            } else {
                avgGain = avgGain * (period - 1) / period;
                avgLoss = (avgLoss * (period - 1) - priceDiff) / period;
            }

            rs = avgLoss == 0 ? Double.POSITIVE_INFINITY : avgGain / avgLoss;
            rsi = 100 - (100 / (1 + rs));
        }

        return rsi;
    }

    private static double calculateAverage(double[] values, int period) {
        double sum = 0;
        for (int i = 1; i <= period; i++) {
            sum += values[i];
        }
        return sum / period;
    }

    /*public static void main(String[] args) {
        // Example usage:
        List<Double> priceData = Arrays.asList(50.0, 51.0, 49.0, 48.0, 52.0, 53.0, 55.0, 54.0, 56.0, 55.0, 57.0,62.0, 58.0, 60.0,61.0);
        int rsiPeriod = 14;

        double rsi = calculateRSI(priceData, rsiPeriod);
        System.out.println("RSI: " + rsi);
    }*/
}
