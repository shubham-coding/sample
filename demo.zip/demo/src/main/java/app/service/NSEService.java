package app.service;

import app.model.ModelResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

import java.util.Arrays;
import java.util.List;

@Service
public class NSEService {

    private final String apiUrl = "https://latest-stock-price.p.rapidapi.com";

    private final WebClient webClient;
    private final RestTemplate restTemplate;

    public NSEService(WebClient.Builder webClientBuilder, RestTemplate restTemplate) {
        this.webClient = webClientBuilder.baseUrl(apiUrl).build();
        this.restTemplate = restTemplate;
    }

    public Flux<ModelResponse> getLiveStockData() {
        // Make HTTP request to NSE API endpoint
        return webClient.get()
                .uri("/price?Indices=NIFTY 50")
                .headers(headers -> headers.set("X-RapidAPI-Key","b05195beb2msh5cf6835d39e8d3ap186b71jsn015477ed7894"))
                .headers(headers -> headers.set("X-RapidAPI-Host","latest-stock-price.p.rapidapi.com"))
                .retrieve()
                .bodyToFlux(ModelResponse.class);
    }

    public List<ModelResponse> getLiveStockDataRestTemplate() {
        String url = apiUrl + "/price?Indices=NIFTY 50";

        ModelResponse[] stockDataArray = restTemplate.getForObject(url, ModelResponse[].class);

        return Arrays.asList(stockDataArray);
    }

}
