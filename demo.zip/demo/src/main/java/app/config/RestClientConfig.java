package app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

@Configuration
public class RestClientConfig {

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setInterceptors(Arrays.asList(headerInterceptor()));
        return restTemplate;
    }

    @Bean
    public ClientHttpRequestInterceptor headerInterceptor() {
        return (request, body, execution) -> {
            request.getHeaders().set("X-RapidAPI-Key", "b05195beb2msh5cf6835d39e8d3ap186b71jsn015477ed7894");
            request.getHeaders().set("X-RapidAPI-Host", "latest-stock-price.p.rapidapi.com");
            // Add other headers as needed
            return execution.execute(request, body);
        };
    }
}
