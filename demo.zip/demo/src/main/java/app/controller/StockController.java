package app.controller;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import app.service.RSIintegration;

@RestController
@RequestMapping("/stocks")
public class StockController {

    //private final NSEService nseService;
    private final RSIintegration rsIintegration;

    public StockController(RSIintegration rsIintegration) {
        this.rsIintegration = rsIintegration;
    }

    @GetMapping("/live")
    public HttpStatus getRSIData() {
        rsIintegration.integrate();
        return HttpStatus.OK;
    }

}
