package app.model;

import java.util.List;

public class NseResponse {

    private List<ModelResponse> modelResponses ;

    public List<ModelResponse> getModelResponses() {
        return modelResponses;
    }

    public void setModelResponses(List<ModelResponse> modelResponses) {
        this.modelResponses = modelResponses;
    }
}
